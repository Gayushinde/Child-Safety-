import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
class homepage extends JFrame{
    JPanel panel;
    JScrollPane scrollPane;
    homepage(){
        panel = new JPanel();
        panel.setLayout(null);
        scrollPane = new JScrollPane(panel);
        add(scrollPane);
        ImageIcon icon=new ImageIcon("img/bg.jpg");
            JLabel lbl=new JLabel(icon);
            lbl.setSize(1366,768);
            panel.add(lbl);
        JMenuBar mb=new JMenuBar();
        mb.setOpaque(true);
        mb.setBorder(new EmptyBorder(0, 0, 0, 0));
        this.setJMenuBar(mb);
        mb.setBackground(Color.decode("#000"));
        mb.add(Box.createHorizontalStrut(10));
        JMenu logo=new JMenu("BabyCare");
        logo.setFont(new Font("Calibri",Font.BOLD,22));
        logo.setForeground(Color.white);
        mb.add(logo);
        mb.add(Box.createVerticalStrut(50));
        mb.add(Box.createHorizontalStrut(300));
        JMenu menu1=new JMenu("Baby Names");
        mb.add(menu1);
        mb.add(Box.createHorizontalStrut(40));
        menu1.setForeground(Color.white);
        JMenu menu2=new JMenu("Tips");
        mb.add(menu2);
        mb.add(Box.createHorizontalStrut(40));
        JMenu menu3=new JMenu("Food");
        mb.add(menu3);
        mb.add(Box.createHorizontalStrut(40));
        JMenu menu4=new JMenu("Admin");
        mb.add(menu4);
        mb.add(Box.createHorizontalStrut(40));
        menu1.setForeground(Color.WHITE);
        menu2.setForeground(Color.WHITE);
        menu3.setForeground(Color.white);
        menu4.setForeground(Color.WHITE);
        this.setTitle("BabyCare - Homepage");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        panel.setPreferredSize(new Dimension(1345, 768));
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[] args) {
        new homepage();
    }
}